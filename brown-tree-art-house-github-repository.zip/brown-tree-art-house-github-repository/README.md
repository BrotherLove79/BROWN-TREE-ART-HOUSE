# Brown Tree Art House — Image Repository

**Community • Creativity • Change**

A starter image library for the Brown Tree Art House nonprofit, organized for use on a website, social media, fundraising materials, and program planning.

## Contents

- `images/` — 50 numbered concept-image tiles
- `LICENSE` — MIT license for the repository's original organizational code/text; see image note below
- `.gitignore` — common local/editor files

## Image note

These 50 JPEGs are individual crops from a generated concept contact sheet. They are **visual concept/reference tiles**, not 50 separately generated high-resolution source artworks. Some lettering or tiny text in the source concepts may be imperfect. Before public or print use, replace any concept tile with a clean, separately created image and proofread all text. Do not rely on concept mockups for legal, financial, property, or official organizational documents.

## Suggested use

- Website galleries and draft layouts
- Social-media planning
- Program and campaign mood boards
- Discussion with designers and volunteers

## Suggested GitHub setup

1. Sign in to GitHub and choose **New repository**.
2. Name it `brown-tree-art-house`.
3. Choose Public or Private, then create the repository.
4. Upload the contents of this ZIP (the `README.md`, `LICENSE`, `.gitignore`, and `images/` folder) to the repository.
5. Commit the files. GitHub will display this README and the image files.

## Accessibility and brand guidance

Use descriptive alt text when publishing images. Keep the Brown Tree Art House identity respectful, inclusive, and focused on arts, education, families, community opportunity, and positive representation. Obtain permission for real people's photographs and verify rights for any third-party material before publication.

## Image index

- `01-logo.jpg`
- `02-banner.jpg`
- `03-mission.jpg`
- `04-vision.jpg`
- `05-values.jpg`
- `06-youth-arts.jpg`
- `07-senior-enrichment.jpg`
- `08-family-programs.jpg`
- `09-tutoring-academics.jpg`
- `10-stem-universe.jpg`
- `11-motivation.jpg`
- `12-workshop-flyer.jpg`
- `13-community-art-festival.jpg`
- `14-donation-appeal.jpg`
- `15-volunteer-recruitment.jpg`
- `16-grant-application.jpg`
- `17-fundraising-strategy.jpg`
- `18-strategic-plan.jpg`
- `19-impact-report.jpg`
- `20-success-story.jpg`
- `21-website-mockup.jpg`
- `22-social-media.jpg`
- `23-program-brochure.jpg`
- `24-registration-form.jpg`
- `25-newsletter.jpg`
- `26-event-calendar.jpg`
- `27-program-budget.jpg`
- `28-annual-impact-report.jpg`
- `29-community-partners.jpg`
- `30-media-kit.jpg`
- `31-press-release.jpg`
- `32-board-of-directors.jpg`
- `33-bylaws-cover.jpg`
- `34-conflict-of-interest-policy.jpg`
- `35-financial-controls.jpg`
- `36-three-year-budget.jpg`
- `37-program-outline.jpg`
- `38-grant-template.jpg`
- `39-donation-receipt.jpg`
- `40-volunteer-signup.jpg`
- `41-building-plans.jpg`
- `42-home-design-concept.jpg`
- `43-property-map-concept.jpg`
- `44-property-tax-information.jpg`
- `45-community-outreach.jpg`
- `46-scholarships.jpg`
- `47-study-abroad.jpg`
- `48-royal-minds-academy.jpg`
- `49-cyrene-lodge.jpg`
- `50-contact-card.jpg`
